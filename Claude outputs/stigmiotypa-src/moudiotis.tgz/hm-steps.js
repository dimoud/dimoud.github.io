/* Βήματα τρέιλερ: η επισήμανση ακολουθεί την κύλιση — κάτω προχωρά, πάνω γυρίζει πίσω.
   istoselides v2.11 (references/15 §Β/Γ — ΜΗ-35/36): γεωμετρία μετρημένη ΜΙΑ φορά (και σε
   resize/load/αλλαγή μεγέθους)· ανά καρέ μόνο scrollY και αλλαγή κλάσης μόνο όταν αλλάζει το βήμα. */
(function () {
    var rail = document.querySelector('.hm-rail'); if (!rail) return;
    var items = rail.querySelectorAll('li'); if (!items.length) return;
    if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    var n = items.length, raf = 0, last = -2, lastProg = -1;
    var G = { vertical: false, tops: [], mids: [], railTop: 0 };
    rail.classList.add('is-playing');
    function measure() {
        var sy = window.scrollY, r0 = items[0].getBoundingClientRect(), r1 = items[n - 1].getBoundingClientRect();
        G.vertical = r1.top - r0.top > 10;
        G.tops = []; G.mids = [];
        for (var k = 0; k < n; k++) { var r = items[k].getBoundingClientRect(); G.tops[k] = r.top + sy; G.mids[k] = r.top + r.height / 2 + sy; }
        G.railTop = rail.getBoundingClientRect().top + sy;
    }
    function paint(sy) {
        raf = 0;
        var vh = window.innerHeight, i, prog;
        if (G.vertical) {
            /* κάθετη λίστα (κινητό): «γραμμή ανάγνωσης» στο 55% της οθόνης */
            var line = vh * 0.55, c0 = G.mids[0] - sy, c1 = G.mids[n - 1] - sy;
            prog = Math.min(1, Math.max(0, (line - c0) / (c1 - c0)));
            i = -1;
            for (var k = 0; k < n; k++) { if (G.tops[k] - sy <= line) i = k; }
            if (i < 0 && G.tops[0] - sy < vh * 0.9) i = 0;
        } else {
            /* οριζόντια σειρά (υπολογιστής): πρόοδος όσο η σειρά ανεβαίνει από το 85% στο 30% της οθόνης */
            var top = G.railTop - sy;
            prog = Math.min(1, Math.max(0, (vh * 0.85 - top) / (vh * 0.55)));
            i = top < vh * 0.9 ? Math.min(n - 1, Math.floor(prog * n)) : -1;
        }
        if (Math.abs(prog - lastProg) > 0.002) { lastProg = prog; rail.style.setProperty('--hm-prog', prog.toFixed(4)); }
        if (i === last) return; last = i;
        items.forEach(function (li, k) { li.classList.toggle('is-active', k === i); li.classList.toggle('is-done', k < i); });
    }
    function req() { if (!raf) raf = requestAnimationFrame(function () { paint(window.scrollY); }); }
    function remeasure() { measure(); req(); }
    /* κοινό καρέ κύλισης του eng-animations.js (μία ανάγνωση θέσης ανά καρέ) — αλλιώς δικός μας ακροατής */
    if (window.ScrollFrame) window.ScrollFrame.add(function (y) { paint(y); });
    else window.addEventListener('scroll', req, { passive: true });
    window.addEventListener('resize', remeasure);
    window.addEventListener('load', remeasure);
    if ('ResizeObserver' in window) new ResizeObserver(remeasure).observe(document.body);
    measure(); paint(window.scrollY);
})();

/* Έλεγχος Κ.Ο.Κ.: τα σημεία φωτίζονται ένα-ένα· μετά εναλλάσσεται το σχέδιο (κλειστό ρυμουλκούμενο ↔ τρέιλερ λέμβου) */
(function () {
    var sec = document.querySelector('.hm-rc'); if (!sec) return;
    var svgs = sec.querySelectorAll('.hm-rc-stage .hm-trailer'), kinds = sec.querySelectorAll('.hm-rc-kind span');
    var rows = sec.querySelectorAll('.hm-pinlist li'); if (!svgs.length || !rows.length) return;
    if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    var s = 0, i = -1, timer = null, STEP = 1700;
    function parts() { return { pins: svgs[s].querySelectorAll('.hm-pins > g'), leads: svgs[s].querySelectorAll('.hm-leads > line') }; }
    function paint() {
        var p = parts(), n = rows.length;
        for (var k = 0; k < n; k++) {
            var on = k === i;
            rows[k].classList.toggle('is-active', on);
            if (p.pins[k]) p.pins[k].classList.toggle('is-active', on);
            if (p.leads[k]) p.leads[k].classList.toggle('is-active', on);
        }
        sec.classList.toggle('is-cycling', i >= 0);
    }
    function show(k) {
        svgs.forEach(function (el, j) { el.classList.toggle('is-shown', j === k); });
        kinds.forEach(function (el, j) { el.classList.toggle('is-shown', j === k); });
    }
    function tick() {
        i++;
        if (i >= rows.length) {
            i = -1; paint();
            if (svgs.length > 1) { s = (s + 1) % svgs.length; show(s); timer = setTimeout(tick, 2600); }
            else timer = setTimeout(tick, 900);
            return;
        }
        paint(); timer = setTimeout(tick, STEP);
    }
    function start() { if (timer) return; timer = setTimeout(tick, 1800); }
    function stop() { clearTimeout(timer); timer = null; }
    var art = sec.querySelector('.hm-rc-art') || sec;
    if ('IntersectionObserver' in window) { new IntersectionObserver(function (es) { es.forEach(function (e) { if (e.isIntersecting) start(); else stop(); }); }, { threshold: 0.3 }).observe(art); } else { start(); }
})();

/* Εγκρίσεις τύπου: η γραμμή που περνά από τη μέση της οθόνης φωτίζεται — ακολουθεί την κύλιση και στις δύο κατευθύνσεις.
   istoselides v2.11 (ΜΗ-36): θέσεις από μνήμης, ανά καρέ μόνο scrollY. */
(function () {
    var list = document.querySelector('.hm-idx'); if (!list) return;
    var rows = list.querySelectorAll('li'); if (!rows.length) return;
    if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    var raf = 0, last = -2, T = [], H = [];
    list.classList.add('is-scrub');
    function measure() {
        var sy = window.scrollY;
        rows.forEach(function (li, k) { var r = li.getBoundingClientRect(); T[k] = r.top + sy; H[k] = r.height; });
    }
    function paint(sy) {
        raf = 0;
        var vh = window.innerHeight, line = vh * 0.55, i = -1, best = 1e9;
        for (var k = 0; k < rows.length; k++) {
            var top = T[k] - sy, bottom = top + H[k];
            if (bottom < vh * 0.12 || top > vh * 0.9) continue;
            var d = Math.abs(top + H[k] / 2 - line);
            if (d < best) { best = d; i = k; }
        }
        if (i === last) return; last = i;
        rows.forEach(function (li, k) { li.classList.toggle('is-focus', k === i); });
    }
    function req() { if (!raf) raf = requestAnimationFrame(function () { paint(window.scrollY); }); }
    function remeasure() { measure(); req(); }
    /* κοινό καρέ κύλισης του eng-animations.js (μία ανάγνωση θέσης ανά καρέ) — αλλιώς δικός μας ακροατής */
    if (window.ScrollFrame) window.ScrollFrame.add(function (y) { paint(y); });
    else window.addEventListener('scroll', req, { passive: true });
    window.addEventListener('resize', remeasure);
    window.addEventListener('load', remeasure);
    if ('ResizeObserver' in window) new ResizeObserver(remeasure).observe(document.body);
    measure(); paint(window.scrollY);
})();

/* Hero: όταν ο επισκέπτης δεν κινείται για λίγα δευτερόλεπτα, τα εικονίδια των ετικετών κάνουν έναν διακριτικό χτύπο */
(function () {
    if (!document.querySelector('.hero-cta-block .hero-pillar')) return;
    var t = null, b = document.body;
    function active() { b.classList.remove('hp-idle'); clearTimeout(t); t = setTimeout(function () { b.classList.add('hp-idle'); }, 3500); }
    ['scroll', 'touchstart', 'mousemove', 'keydown', 'wheel'].forEach(function (ev) { window.addEventListener(ev, active, { passive: true }); });
    active();
})();

/* Hero: ο τίτλος «Εγκρίσεις Τύπου | Ταξινόμηση Οχημάτων | Τεχνικές Μελέτες» σε μία γραμμή,
   με μέγεθος γραμμάτων τέτοιο ώστε να πιάνει ακριβώς το πλάτος των κουμπιών από κάτω. */
(function () {
    var h = document.querySelector('.hero-headline'), ref = document.querySelector('.hero-actions');
    if (!h || !ref || !document.createRange) return;
    var busy = false;
    var nameLine = document.querySelector('.hero-name .line2'), cta = document.querySelector('.hero-cta-block');
    function fit() {
        if (busy) return; busy = true;
        /* Υπολογιστής: όνομα, τίτλος, κουμπιά και πλαίσια στο ίδιο πλάτος — το πλάτος της στήλης (ίδια αριστερή και δεξιά ευθεία) */
        var inner = h.parentNode;
        if (cta && nameLine) {
            nameLine.style.removeProperty('font-size');
            [cta, ref, document.querySelector('.hero-pillars')].forEach(function (el) { if (el) { el.style.removeProperty('width'); el.style.removeProperty('max-width'); } });
            if (window.innerWidth > 768) {
                var cs = getComputedStyle(inner), col = inner.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
                [cta, ref, document.querySelector('.hero-pillars')].forEach(function (el) { if (el) { el.style.setProperty('width', col + 'px', 'important'); el.style.setProperty('max-width', 'none', 'important'); } });
                for (var it = 0; it < 2; it++) {
                    var nr = document.createRange(); nr.selectNodeContents(nameLine);
                    var nw = nr.getBoundingClientRect().width, nf = parseFloat(getComputedStyle(nameLine).fontSize);
                    if (nw > 0) nameLine.style.setProperty('font-size', (nf * col / nw).toFixed(2) + 'px', 'important');
                }
            }
        }
        var target = ref.getBoundingClientRect().width;
        if (target > 0) {
            h.style.setProperty('font-size', '20px', 'important');
            var r = document.createRange(); r.selectNodeContents(h);
            var w = r.getBoundingClientRect().width;
            if (w > 0) {
                var fs = Math.max(11, Math.min(34, 20 * target / w));
                h.style.setProperty('font-size', fs.toFixed(2) + 'px', 'important');
            }
        }
        busy = false;
    }
    fit();
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(fit);
    window.addEventListener('load', fit);
    var t; window.addEventListener('resize', function () { clearTimeout(t); t = setTimeout(fit, 80); });
    if ('MutationObserver' in window) new MutationObserver(function () { if (!busy) fit(); }).observe(h, { childList: true, characterData: true, subtree: true });
})();

/* Άδεια τρέιλερ (αρχική, υπολογιστής): βήματα και κουμπί «Ο πλήρης οδηγός» μέχρι τη δεξιά άκρη του τίτλου. */
(function () {
    var sec = document.querySelector('.hm-tr'), h = document.getElementById('hmTrH');
    if (!sec || !h || !document.createRange) return;
    function fit() {
        if (window.innerWidth <= 768) { sec.style.removeProperty('--hm-tr-w'); return; }
        var r = document.createRange(); r.selectNodeContents(h);
        var w = r.getBoundingClientRect().width;
        if (w > 0) sec.style.setProperty('--hm-tr-w', Math.ceil(w) + 'px');
    }
    fit();
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(fit);
    window.addEventListener('load', fit);
    var t; window.addEventListener('resize', function () { clearTimeout(t); t = setTimeout(fit, 80); });
    if ('MutationObserver' in window) new MutationObserver(fit).observe(h, { childList: true, characterData: true, subtree: true });
})();
