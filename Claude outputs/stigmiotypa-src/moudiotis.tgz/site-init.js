/**
 * site-init.js — Site Initializer & Rendering Engine
 * ════════════════════════════════════════════════════════════════════════════
 * LOAD ORDER CRITICAL — no defer, no async.
 * Must be loaded at the bottom of <body>, AFTER config.js (which is in <head>),
 * and BEFORE eng-animations.js and i18n.js.
 *
 * Why synchronous (no DOMContentLoaded wrapper):
 *   Scripts at the bottom of <body> run after all HTML above them is parsed.
 *   The DOM is fully available. Rendering here synchronously means that when
 *   eng-animations.js runs next, it can observe ALL [data-reveal] elements —
 *   including the dynamically rendered service cards and project cards.
 *   Using DOMContentLoaded would delay rendering until after eng-animations.js
 *   has already scanned the DOM, causing those cards to never animate.
 *
 * Responsibilities:
 *   1. Build window.SITE_CONFIG.translations from config data  →  for i18n.js
 *   2. Inject CSS theme variables (accent color override)
 *   3. Set <title> and <meta description>
 *   4. Set asset sources (logo, photo, hero slides)
 *   5. Set contact links (phone, email)
 *   6. Set measurement labels (auto-generated from array lengths)
 *   7. Set name fields (nav brand, contact person, footer)
 *   8. Render marquee items
 *   9. Render about features
 *  10. Render services grid
 *  11. Render projects grid
 *  12. Render contact form dropdown options
 * ════════════════════════════════════════════════════════════════════════════
 */

/* LOAD ORDER CRITICAL — no defer, no async */

(function () {
    'use strict';

    var C = window.SITE_CONFIG;
    /* Κρυφές υπηρεσίες (hidden: true στο config): κρατιούνται, δεν εμφανίζονται */
    if (C && C.services) C.services = C.services.filter(function (s) { return !s.hidden; });
    if (!C) {
        console.error('[site-init] window.SITE_CONFIG not found. Did config.js load before site-init.js?');
        return;
    }

    var P = C.profile;
    var A = C.about;


    // ── 1. BUILD TRANSLATIONS ────────────────────────────────────────────────
    var T = {};

    var yearsExp = new Date().getFullYear() - (P.expStartYear || 2000);
    function injectYears(str) {
        return (str || '').replace(/\{years\}/g, yearsExp);
    }

    // NAV
    T['nav.title']    = { el: P.professionEl,  en: P.professionEn };
    T['nav.about']    = { el: 'Σχετικά',       en: 'About' };
    T['nav.services'] = { el: 'Υπηρεσίες',     en: 'Services' };
    T['nav.approvals'] = { el: 'Εγκρίσεις Τύπου', en: 'Type Approvals' };
    T['nav.trust']    = { el: 'Αξιοπιστία',    en: 'Why Us' };
    T['nav.contact']  = { el: 'Επικοινωνία',   en: 'Contact' };
    T['nav.trailer']  = { el: 'Άδεια Τρέιλερ Ο1/Ο2',        en: 'Trailer Licence' };
    T['nav.imports']  = { el: 'Εισαγόμενα, Τροχόσπιτα',     en: 'Imports, Caravans' };
    T['nav.tao']      = { el: 'Έγκριση Τύπου, ΤΑΟ',         en: 'Type Approval, TAO' };
    T['nav.moto']     = { el: 'Δίκυκλα, Τετράκυκλα',        en: 'Two-wheelers, Quads' };
    T['nav.special']  = { el: 'Ειδικού Σκοπού',              en: 'Special Purpose' };





    // ── ΑΡΧΙΚΗ: ΤΕΣΣΕΡΙΣ ΣΤΙΓΜΕΣ ΥΠΗΡΕΣΙΩΝ ──
    T["hm.ta.eyebrow"] = { el: "Εγκρίσεις τύπου", en: "Type approvals" };
    T["hm.ta.h"] = { el: "Από τον φάκελο <em>ως την ταξινόμηση</em>", en: "From the dossier <em>to registration</em>" };
    T["hm.ta.p"] = { el: "Για εισαγωγείς, κατασκευαστές και ιδιώτες. Αναλαμβάνουμε ολόκληρο τον φάκελο έγκρισης, σε όλη την Ελλάδα.", en: "For importers, manufacturers and private owners. We take on the whole approval dossier, across Greece." };
    T["hm.ta.cta"] = { el: "Ζητήστε προσφορά", en: "Request a quote" };
    T["hm.ta.1.t"] = { el: "Δελτίο Κοινοποίησης και ΤΑΟ", en: "Notification and TAO" };
    T["hm.ta.1.d"] = { el: "Για εισαγωγείς και αντιπροσωπείες", en: "For importers and dealers" };
    T["hm.ta.2.t"] = { el: "Έγκριση Τύπου Οχήματος", en: "Vehicle Type Approval" };
    T["hm.ta.2.d"] = { el: "Εθνική και ευρωπαϊκή · οχήματα, αμαξώματα, ρυμουλκούμενα", en: "National and EU · vehicles, bodies, trailers" };
    T["hm.ta.3.t"] = { el: "Μεμονωμένη Έγκριση", en: "Individual Approval" };
    T["hm.ta.3.d"] = { el: "Εισαγόμενα και τροχόσπιτα", en: "Imports and caravans" };
    T["hm.ta.4.t"] = { el: "Κατηγορία L", en: "Category L" };
    T["hm.ta.4.d"] = { el: "Μοτοσικλέτες, τρίκυκλα, τετράκυκλα", en: "Motorcycles, tricycles, quads" };
    T["hm.ta.5.t"] = { el: "Ειδικού Σκοπού", en: "Special Purpose" };
    T["hm.ta.5.d"] = { el: "Γερανοφόρα, καντίνες, κινητές μονάδες", en: "Crane trucks, catering units, mobile units" };
    T["hm.tr.eyebrow"] = { el: "Άδεια τρέιλερ Ο1 · Ο2", en: "O1 · O2 trailer licence" };
    T["hm.tr.h"] = { el: "Το τρέιλερ σας, <em>νόμιμο</em> σε οκτώ βήματα", en: "Your trailer, <em>legal</em> in eight steps" };
    T["hm.tr.p"] = { el: "Ρυμουλκούμενο ή μπαγκαζιέρα έως 3,5 τόνους χωρίς άδεια; Αναλαμβάνουμε τα πάντα, από τα δικαιολογητικά μέχρι τις πινακίδες.", en: "A trailer or cargo box up to 3.5 tonnes without a licence? We handle everything, from the documents to the number plates." };
    T["hm.tr.s1"] = { el: "Συγκέντρωση δικαιολογητικών", en: "Collecting the documents" };
    T["hm.tr.s2"] = { el: "Κατάθεση στην υπηρεσία", en: "Filing with the authority" };
    T["hm.tr.s3"] = { el: "Χάραξη νέου 17ψήφιου αριθμού", en: "Engraving the new 17-digit number" };
    T["hm.tr.s4"] = { el: "Επιθεώρηση", en: "Inspection" };
    T["hm.tr.s5"] = { el: "Τεχνικός φάκελος", en: "Technical dossier" };
    T["hm.tr.s6"] = { el: "Τελική κατάθεση", en: "Final filing" };
    T["hm.tr.s7"] = { el: "Έλεγχος", en: "Authority check" };
    T["hm.tr.s8"] = { el: "Πινακίδες", en: "Number plates" };
    T["hm.tr.warn"] = { el: "Μέχρι να εκδοθούν άδεια και πινακίδες, το ρυμουλκούμενο δεν κυκλοφορεί.", en: "Until the licence and plates are issued, the trailer may not be driven." };
    T["hm.tr.cta"] = { el: "Ο πλήρης οδηγός", en: "The full guide" };
    T["hm.rc.eyebrow"] = { el: "Έλεγχος Κ.Ο.Κ.", en: "Highway Code check" };
    T["hm.rc.h"] = { el: "Πριν βγείτε <em>στον δρόμο</em>", en: "Before you hit <em>the road</em>" };
    T["hm.rc.p"] = { el: "Τα σημεία που πρέπει να είναι σε τάξη ώστε το ρυμουλκούμενο να είναι σύμφωνο με τον Κ.Ο.Κ. και ασφαλές.", en: "The points that must be in order for the trailer to comply with the Highway Code and be safe." };
    T["hm.rc.1"] = { el: "Σύστημα ζεύξης", en: "Coupling system" };
    T["hm.rc.2"] = { el: "Ρόδα στήριξης", en: "Jockey wheel" };
    T["hm.rc.3"] = { el: "Πλευρικοί ανακλαστήρες", en: "Side reflectors" };
    T["hm.rc.4"] = { el: "Λασπωτήρες", en: "Mudguards" };
    T["hm.rc.5"] = { el: "Πίσω τρίγωνα", en: "Rear triangles" };
    T["hm.rc.6"] = { el: "Πίσω φώτα", en: "Rear lights" };
    T["hm.rc.7"] = { el: "Πινακίδα κυκλοφορίας", en: "Number plate" };
    T["hm.rc.8"] = { el: "Ξεχωριστή ασφάλιση", en: "Separate insurance" };
    T["hm.rc.k1"] = { el: "Κλειστό ρυμουλκούμενο", en: "Box trailer" };
    T["hm.rc.k2"] = { el: "Τρέιλερ λέμβου", en: "Boat trailer" };
    T["hm.rc.cta"] = { el: "Κάντε τον πλήρη έλεγχο", en: "Run the full check" };
    T["hm.q.eyebrow"] = { el: "Υπολογιστής έλξης", en: "Towing calculator" };
    T["hm.q.h"] = { el: "Επιτρέπεται να τραβήξω <em>αυτό</em> το&nbsp;ρυμουλκούμενο;", en: "May I tow <em>this</em> trailer?" };
    T["hm.q.p"] = { el: "Βάλτε τους κωδικούς από τις δύο άδειες κυκλοφορίας. Η απάντηση βγαίνει αμέσως.", en: "Enter the codes from the two registration certificates. You get the answer straight away." };
    T["hm.q.car"] = { el: "Έλκον όχημα", en: "Towing vehicle" };
    T["hm.q.trl"] = { el: "Ρυμουλκούμενο", en: "Trailer" };
    T["hm.q.o1"] = { el: "Μέγιστη ρυμουλκούμενη, με φρένα", en: "Max towable, braked" };
    T["hm.q.o2"] = { el: "Μέγιστη ρυμουλκούμενη, χωρίς φρένα", en: "Max towable, unbraked" };
    T["hm.q.f3"] = { el: "Μέγιστη μάζα συνδυασμού", en: "Max combination mass" };
    T["hm.q.f2"] = { el: "Μέγιστη επιτρεπόμενη μάζα", en: "Max permissible mass" };
    T["hm.q.cta"] = { el: "Ανοίξτε τον υπολογιστή", en: "Open the calculator" };
    // ── /ΑΡΧΙΚΗ ──
    // Πορεία (κάτω από τη φωτογραφία)
    T['stats.1'] = { el: 'Χρόνια εμπειρίας', en: 'Years of experience' };
    T['stats.2'] = { el: 'Χώρες', en: 'Countries' };
    T['stats.3'] = { el: 'Πτυχία', en: 'Degrees' };
    T['path.head'] = { el: 'Πορεία', en: 'Path' };
    T['path.1.t'] = { el: "Μηχανολόγος Μηχανικός", en: "Mechanical Engineer" };
    T['path.1.d'] = { el: "ΑΠΘ · Θεσσαλονίκη", en: "AUTh · Thessaloniki" };
    T['path.2.t'] = { el: "MSc", en: "MSc" };
    T['path.2.d'] = { el: "École Centrale Paris · Γαλλία", en: "École Centrale Paris · France" };
    T['path.3.t'] = { el: "MSc", en: "MSc" };
    T['path.3.d'] = { el: "IFP School · Παρίσι", en: "IFP School · Paris" };
    T['path.4.t'] = { el: "MSc", en: "MSc" };
    T['path.4.d'] = { el: "Ελλάδα", en: "Greece" };
    T['path.5.t'] = { el: 'MBA', en: 'MBA' };
    T['path.5.d'] = { el: 'Washington University of Science and Technology · ΗΠΑ', en: 'Washington University of Science and Technology · USA' };
    T['path.6.t'] = { el: "Τεχνικό Γραφείο Μουδιώτης", en: "Moudiotis Engineering Office" };
    T['path.6.d'] = { el: "Αθήνα · Θεσσαλονίκη", en: "Athens · Thessaloniki" };
    // Αναδυόμενο μενού «Υπηρεσίες»
    T['nav.dd.g1']  = { el: "Εγκρίσεις και Ταξινόμηση", en: "Approvals and Registration" };
    T['nav.dd.g2']  = { el: "Μετατροπές και Ειδικά Οχήματα", en: "Conversions and Special Vehicles" };
    T['nav.dd.all'] = { el: 'Όλες οι υπηρεσίες', en: 'All services' };
    T['svc.more'] = { el: 'Περισσότερα →', en: 'More →' };
    T['nav.dd.deltio-koinopoiisis-tao'] = { el: "Δελτίο Κοινοποίησης και ΤΑΟ", en: "Notification and TAO" };
    T['nav.dd.ethniki-evropaiki-egkrisi-typou'] = { el: "Εθνική και Ευρωπαϊκή Έγκριση", en: "National and EU Approval" };
    T['nav.dd.memonomeni-egkrisi-oximatos'] = { el: "Μεμονωμένη Έγκριση, Εισαγόμενα", en: "Individual Approval, Imports" };
    T['nav.dd.egkrisi-typou-dikyklon'] = { el: "Κατηγορία L: Δίκυκλα, Τετράκυκλα", en: "Category L: Motorcycles, Quads" };
    T['nav.dd.adeia-treiler-o1-o2'] = { el: "Άδεια Τρέιλερ Ο1/Ο2", en: "O1/O2 Trailer Licence" };
    T['nav.dd.kotsadoros-elxi'] = { el: "Κοτσαδόρος και Έλξη", en: "Tow Bar and Towing" };
    T['nav.dd.trochospita'] = { el: "Τροχόσπιτα", en: "Caravans" };
    T['nav.dd.metatropi-van-se-trochospito'] = { el: "Βαν σε Αυτοκινούμενο", en: "Van to Motor Caravan" };
    T['nav.dd.oximata-eidikou-skopou'] = { el: "Οχήματα Ειδικού Σκοπού", en: "Special Purpose Vehicles" };
    T['nav.dd.metaskeves-yperkataskeves'] = { el: "Μετασκευές, Υπερκατασκευές", en: "Conversions, Superstructures" };
    T['nav.dd.topothetisi-geranou'] = { el: "Τοποθέτηση Γερανού", en: "Crane Installation" };
    T['nav.dd.texniki-symvouleftiki'] = { el: "Βεβαιώσεις Μηχανικού", en: "Engineer Certificates" };




    // NEWS
    T['news.eyebrow'] = { el: 'ΕΝΗΜΕΡΩΣΗ', en: 'UPDATES' };
    T['news.heading'] = { el: 'Νομοθεσία και <em>νέα</em> του κλάδου', en: 'Industry <em>news</em> and legislation' };

    // HERO
    T['hero.name1']   = { el: P.firstNameEl,   en: P.firstNameEn };
    T['hero.name2']   = { el: P.lastNameEl,    en: P.lastNameEn };
    T['hero.name3']   = { el: P.suffixEl || '', en: P.suffixEn || '' };
    T['hero.eyebrow'] = {
        el: P.universityEl ? P.professionEl + ' ' + P.universityEl : P.professionEl,
        en: P.universityEn ? P.professionEn + ' \u2014 ' + P.universityEn : P.professionEn,
    };
    T['hero.cta']     = { el: 'Επικοινωνία',   en: 'Get in Touch' };
    /* Πρώτη οθόνη: τι κάνουμε, με ποια εγγύηση, και η απόδειξη αμέσως από κάτω.
       Οι αριθμοί βγαίνουν από το config (κριτικές, έργα, χρόνια), ώστε να μη
       μένουν πίσω όταν αλλάζουν. */
    T['hero.headline'] = {
        el: '<span class="hh-p">Εγκρίσεις Τύπου</span> <span class="hh-sep">|</span> <em class="hh-p">Ταξινόμηση Οχημάτων</em> <span class="hh-sep hh-sep--2">|</span> <span class="hh-p hh-p--3">Τεχνικές Μελέτες</span>',
        en: '<span class="hh-p">Type Approval</span> <span class="hh-sep">|</span> <em class="hh-p">Vehicle Registration</em> <span class="hh-sep hh-sep--2">|</span> <span class="hh-p hh-p--3">Technical Studies</span>',
    };
    T['hero.sub'] = {
        el: 'Μεμονωμένη έγκριση, καταχώρηση στο ΤΑΟ, ρυμουλκούμενα, δίκυκλα και οχήματα ειδικού σκοπού. Αναλαμβάνουμε ολόκληρο τον φάκελο, από τη μελέτη ως τις πινακίδες.',
        en: 'Individual approval, TAO registration, trailers, two-wheelers and special purpose vehicles. We take on the whole file, from the study to the plates.',
    };
    T['hero.cta.quote'] = { el: 'Ζητήστε προσφορά', en: 'Request a quote' };
    (function () {
        var nRev = (C.reviews || []).length;
        var st = (C.trust && C.trust.stats) || [];
        var yrs = st[0] ? injectYears(st[0].numEl) : '';
        var prj = st[1] ? st[1].numEl : '';
        T['hero.proof'] = {
            /* Όλες οι κριτικές στη Google είναι 5 αστέρων (επιβεβαιωμένο από τον ιδιοκτήτη) */
            el: '5,0 · ' + nRev + ' κριτικές στη Google' + (prj ? ' · ' + prj + ' έργα' : '') + (yrs ? ' · ' + yrs + ' χρόνια' : ''),
            en: '5.0 · ' + nRev + ' Google reviews' + (prj ? ' · ' + prj + ' projects' : '') + (yrs ? ' · ' + yrs + ' years' : ''),
        };
    })();
    T['tools.eyebrow'] = { el: 'Εργαλεία ρυμουλκούμενου', en: 'Trailer tools' };
    T['tools.tab1']    = { el: 'Οδηγός άδειας',      en: 'Licence guide' };
    T['tools.tab2']    = { el: 'Έλεγχος Κ.Ο.Κ.',     en: 'Road check' };
    T['tools.tab3']    = { el: 'Υπολογιστής έλξης',  en: 'Towing calculator' };
    T['about.pname']  = { el: 'Δημήτριος Μουδιώτης', en: 'Dimitrios Moudiotis' };
    T['about.ptitle'] = { el: 'Μηχανολόγος Μηχανικός ΑΠΘ, 3× MSc', en: 'Mechanical Engineer AUTH, 3× MSc' };
    T['about.parea']  = { el: 'Αθήνα · Θεσσαλονίκη', en: 'Athens · Thessaloniki' };
    T['hero.p1'] = { el: 'Εγκρίσεις Τύπου',          en: 'Type Approvals' };
    T['hero.p2'] = { el: 'Τεχνικές Μελέτες',         en: 'Technical Studies' };
    T['hero.p3'] = { el: 'Πλήρης Ανάληψη',           en: 'Full Handling' };
    T['hero.p4'] = { el: 'Οχήματα Ειδικού Σκοπού',   en: 'Special Purpose Vehicles' };

    // MARQUEE
    (C.marquee || []).forEach(function (m, i) {
        T['marquee.m' + (i + 1)] = { el: m.el, en: m.en };
    });

    // ABOUT
    T['about.heading'] = { el: A.headingEl, en: A.headingEn };
    T['about.lead']    = { el: injectYears(A.leadEl), en: injectYears(A.leadEn) };
    T['about.dim']     = { el: P.locationEl, en: P.locationEn };

    (A.features || []).forEach(function (f, i) {
        var n = i + 1;
        T['feature.' + n + '.label'] = { el: f.labelEl, en: f.labelEn };
        T['feature.' + n + '.text']  = { el: f.textEl,  en: f.textEn };
    });

    // SERVICES
    T['services.eyebrow'] = { el: 'Τι προσφέρουμε', en: 'What we offer' };
    T['services.heading'] = { el: 'Οι <em>Υπηρεσίες</em> μας', en: 'Our <em>Services</em>' };

    // TRAILER ANNOUNCEMENT GUIDE
    T['ta.badge']       = { el: 'ΝΕΟΣ ΝΟΜΟΣ', en: 'NEW LAW' };
    T['ta.title']       = { el: 'ΤΡΕΪΛΕΡ — Οδηγός Νομιμοποίησης και Έκδοσης Άδειας Κυκλοφορίας', en: 'TRAILER — Legalization and Registration Guide' };
    T['ta.intro']       = {
        el: 'Στις <strong>23 Μαρτίου 2026</strong> ψηφίστηκε νόμος του Υπουργείου Υποδομών και Μεταφορών με αντικείμενο την <strong>κυκλοφορία οχημάτων κατηγορίας Ο1 και Ο2</strong> — δηλαδή ρυμουλκούμενων τρέιλερ. Ο νόμος ορίζει για πρώτη φορά σαφή διαδικασία νομιμοποίησης για τα αναρίθμητα ρυμουλκούμενα που κυκλοφορούν χωρίς άδεια στην Ελληνική επικράτεια. Η διαδικασία είναι πλέον ανοιχτή.',
        en: 'On <strong>23 March 2026</strong>, the Ministry of Infrastructure and Transport enacted a law governing the <strong>circulation of O1 and O2 category vehicles</strong> — i.e. towed trailers. For the first time, the law defines a clear legalization procedure for the many trailers circulating without registration in Greece. The process is now open.'
    };
    T['ta.col1.head']   = { el: 'Ποια οχήματα εντάσσονται', en: 'Eligible vehicles' };
    T['ta.elig1']       = { el: 'Ρυμουλκούμενα με <strong>Ειδικό Σημείωμα Ρυμούλκησης (Ε.Σ.Ρ.)</strong> ή <strong>Υπεύθυνη Δήλωση Μηχανολόγου</strong> με αποτύπωμα πινακιδίου χαρακτηριστικών.', en: 'Trailers with a <strong>Special Towing Note (E.S.R.)</strong> or a <strong>Mechanical Engineer\'s Declaration</strong> with a characteristic plate imprint.' };
    T['ta.elig2']       = { el: 'Ρυμουλκούμενα <strong>ειδικής χρήσης και ειδικού σκοπού</strong>, μη μεταφοράς εμπορευμάτων.', en: 'Trailers of <strong>special use and special purpose</strong>, not intended for goods transport.' };
    T['ta.elig3']       = { el: 'Δεν υπάρχει <strong>ημερομηνία λήξης</strong> της διαδικασίας προς το παρόν — η διαδικασία παραμένει ανοιχτή.', en: 'There is currently <strong>no expiry date</strong> for the process — the window remains open.' };
    T['ta.elig4']       = { el: 'Δεν μπορούν να εκδόσουν άδεια <strong>ρυμουλκούμενα χωρίς προηγούμενη άδεια κυκλοφορίας</strong> (ιδιοκατασκευές).', en: 'Trailers <strong>without a prior registration licence</strong> (home-built) are not eligible.' };
    T['ta.col2.head']   = { el: 'Κόστος και απαιτήσεις', en: 'Cost and requirements' };
    T['ta.proc1']       = { el: 'Παράβολα συνολικά <strong>230 €</strong>, εκδιδόμενα ηλεκτρονικά μέσω <strong>e-paravolo</strong>.', en: 'Total fees of <strong>€230</strong>, issued electronically via <strong>e-paravolo</strong>.' };
    T['ta.proc2']       = { el: 'Για οχήματα με ΕΣΡ πριν το <strong>1999</strong>: <strong>πρακτικό επιθεώρησης</strong> από αρμόδια Υπηρεσία Μεταφορών ή <strong>επιτυχής έλεγχος ΚΤΕΟ</strong>.', en: 'For vehicles with ESR before <strong>1999</strong>: an <strong>inspection report</strong> from the Regional Transport Authority or a <strong>successful KTEO technical check</strong>.' };
    T['ta.proc3']       = { el: 'Υποβολή πλήρους φακέλου <strong>δικαιολογητικών</strong> στην αρμόδια υπηρεσία, με σωστή καταγραφή χαρακτηριστικών οχήματος.', en: 'Submission of a complete <strong>documentation file</strong> to the competent authority, with accurate recording of vehicle characteristics.' };
    T['ta.expand.hint']      = { el: 'ΔΕΣ ΑΝΑΛΥΤΙΚΑ ΤΗ ΔΙΑΔΙΚΑΣΙΑ', en: 'SEE THE FULL PROCESS' };
    T['ta.stat.docs']        = { el: '10–15', en: '10–15' };
    T['ta.stat.docs.lbl']    = { el: 'Δικαιολογητικά', en: 'Documents' };
    T['ta.stat.fee.lbl']     = { el: 'Παράβολα', en: 'Fees' };
    T['ta.stat.days']        = { el: 'ν.5290', en: 'Law 5290' };
    T['ta.stat.days.lbl']    = { el: 'Άρθρο 14 / 2026', en: 'Art. 14 / 2026' };
    T['ta.stat.process']     = { el: 'Βήμα-βήμα', en: 'Step-by-step' };
    T['ta.stat.process.lbl'] = { el: 'Διαδικασία', en: 'Process' };
    T['about.acc0']  = { el: 'Το Αντικείμενο', en: 'What We Do' };
    T['about.art.1'] = { el: 'Μελέτη μηχανικού', en: "Engineer’s study" };
    T['about.art.2'] = { el: 'Άμεση ενημέρωση', en: 'Prompt updates' };
    T['about.art.3'] = { el: 'Έκδοση άδειας', en: 'Licence issued' };
    T['partners.eyebrow']    = { el: 'ΠΕΛΑΤΕΣ & ΣΥΝΕΡΓΑΤΕΣ', en: 'CLIENTS & PARTNERS' };
    T['partners.heading']    = { el: 'Μας <em>εμπιστεύονται</em>', en: 'They <em>trust us</em>' };
    T['partners.note']       = { el: 'Συνεργασίες σε εγκρίσεις τύπου, ταξινομήσεις και τεχνικές μελέτες οχημάτων. Τα λογότυπα ανήκουν στους δικαιούχους τους και δηλώνουν μόνο τη συνεργασία, όχι εκπροσώπηση.', en: 'Partnerships in type approvals, registrations and vehicle technical studies. Logos belong to their owners and indicate cooperation only, not representation.' };
    T['partners.region']     = { el: 'Πελάτες και συνεργάτες', en: 'Clients and partners' };
    T['tool.trailerpage'] = { el: 'Δείτε τη σελίδα: Άδεια Τρέιλερ Ο1/Ο2', en: 'See the full page: Trailer Licence O1/O2' };
    T['ta.price.tag']        = { el: 'ΤΕΛΙΚΗ ΤΙΜΗ', en: 'FINAL PRICE' };
    T['ta.price.val']        = { el: '400–430 €', en: '€400–430' };
    T['ta.price.note']       = { el: 'Για άδεια και πινακίδες ρυμουλκούμενου Ο1 ή Ο2. Συμπεριλαμβάνονται τα παράβολα του Δημοσίου.', en: 'For an O1 or O2 trailer licence and plates. Government fees are included.' };
    T['trc.badge.cat']       = { el: 'ΚΑΤΗΓΟΡΙΑ', en: 'CATEGORY' };
    T['ta.docs.head']   = { el: 'Απαιτούμενα δικαιολογητικά', en: 'Required documents' };
    T['ta.docs.a.head'] = { el: 'Α. Στοιχεία Ιδιοκτήτη', en: 'A. Owner details' };
    T['ta.docs.a1']     = { el: 'Φωτοαντίγραφο Αστυνομικής Ταυτότητας ή Διαβατηρίου', en: 'Copy of National ID or Passport' };
    T['ta.docs.a2']     = { el: 'Αριθμός Φορολογικού Μητρώου (ΑΦΜ)', en: 'Tax Registration Number (VAT/AFM)' };
    T['ta.docs.a3']     = { el: 'Στοιχεία επικοινωνίας (τηλέφωνο, e-mail)', en: 'Contact details (phone, e-mail)' };
    T['ta.docs.b.head'] = { el: 'Β. Στοιχεία Οχήματος', en: 'B. Vehicle details' };
    T['ta.docs.b4']     = { el: '<strong>Πρωτότυπο Σημείωμα Ρυμούλκησης / ΥΔ Μηχανολόγου</strong>', en: '<strong>Original Towing Note / Engineer\'s Declaration</strong>' };
    T['ta.docs.b5']     = { el: 'Τιμολόγιο αγοράς ή αποδεικτικό ιδιοκτησίας του τρέιλερ (αν υπάρχει)', en: 'Purchase invoice or proof of ownership (if available)' };
    T['ta.docs.b6']     = { el: 'Παλαιός αριθμός πλαισίου — φωτογραφία (αν υπάρχει) <strong>και αποτύπωμα αν είναι δυνατό</strong>', en: 'Old chassis number — photo (if available) <strong>and imprint if possible</strong>' };
    T['ta.docs.b7']     = { el: 'Φωτογραφία παλαιού ταμπελακιού (αν υπάρχει)', en: 'Photo of old manufacturer plate (if available)' };
    T['ta.docs.b8']     = { el: 'Φωτογραφίες όλων των πλευρών του ρυμουλκούμενου (ολόκληρο, κεντραρισμένο)', en: 'Photos of all sides of the trailer (full view, centred)' };
    T['ta.docs.b9']     = { el: 'Φωτογραφία σημείου ζεύξης', en: 'Photo of the coupling point' };
    T['ta.docs.b10']    = { el: 'Ζυγολόγιο (αν υπάρχει)', en: 'Weighbridge certificate (if available)' };
    T['ta.docs.b11']    = { el: 'Φωτογραφία άδειας κυκλοφορίας έλκοντος οχήματος', en: 'Photo of the towing vehicle\'s registration certificate' };
    T['ta.docs.c.head'] = { el: 'Γ. Έγγραφα', en: 'C. Documents' };
    T['ta.docs.c1']     = { el: 'Αίτηση με γνήσιο υπογραφής (ΚΕΠ ή gov)', en: 'Application with certified signature (KEP or gov.gr)' };
    T['ta.docs.c2']     = { el: 'Εξουσιοδότηση με γνήσιο υπογραφής (ΚΕΠ ή gov)', en: 'Power of attorney with certified signature (KEP or gov.gr)' };
    T['ta.docs.c3']     = { el: 'ΥΔ ιδιοκτησίας', en: 'Statutory declaration of ownership' };
    T['ta.docs.c4']     = { el: 'Παράβολο <strong>200 €</strong> μέσω e-paravolo, κωδ. <strong>15</strong> — στο ΑΦΜ του ιδιοκτήτη <em>(μπορεί να πληρωθεί αργότερα)</em>', en: '<strong>€200</strong> fee via e-paravolo, code <strong>15</strong> — under the owner\'s AFM <em>(can be paid later)</em>' };
    T['ta.docs.c5']     = { el: 'Παράβολο <strong>30 €</strong> μέσω e-paravolo, κωδ. <strong>2992</strong> — στο ΑΦΜ του ιδιοκτήτη <em>(μπορεί να πληρωθεί αργότερα)</em>', en: '<strong>€30</strong> fee via e-paravolo, code <strong>2992</strong> — under the owner\'s AFM <em>(can be paid later)</em>' };
    T['ta.warn.title']  = { el: 'Προσοχή — Απαγόρευση κυκλοφορίας', en: 'Caution — Circulation Prohibited' };
    T['ta.warn.text']   = { el: 'Έως την έκδοση της άδειας κυκλοφορίας και των πινακίδων, <strong>απαγορεύεται ρητά η κυκλοφορία</strong> των παραπάνω οχημάτων. Σε ενδεχόμενο ελέγχου, αντιμετωπίζονται ως οχήματα <strong>χωρίς στοιχεία κυκλοφορίας και ανασφάλιστα</strong>, με ό,τι αυτό συνεπάγεται νομικά και οικονομικά.', en: 'Until the registration and plates are issued, <strong>circulation of these vehicles is strictly prohibited</strong>. If stopped during a check, they are treated as <strong>unregistered and uninsured</strong>, with all the legal and financial consequences that entails.' };
    T['ta.svc.head']    = { el: 'Τι αναλαμβάνει το γραφείο μας', en: 'What our office handles' };
    T['ta.svc1']        = { el: '<strong>Επιθεώρηση και καταγραφή</strong> — Ελέγχουμε το ρυμουλκούμενο και καταγράφουμε με ακρίβεια όλα τα χαρακτηριστικά του, ώστε η νέα άδεια κυκλοφορίας να εκδοθεί σωστά.', en: '<strong>Inspection and recording</strong> — We inspect the trailer and accurately record all its characteristics, ensuring the new registration is issued correctly.' };
    T['ta.svc2']        = { el: '<strong>Αποτύπωση και πινακίδιο</strong> — Αποτυπώνουμε τον νέο <strong>17ψήφιο αριθμό πλαισίου (VIN)</strong> και τοποθετούμε το πινακίδιο χαρακτηριστικών.', en: '<strong>VIN and plate</strong> — We stamp the new <strong>17-digit chassis number (VIN)</strong> and fit the characteristic plate.' };
    T['ta.svc3']        = { el: '<strong>Πλήρης μελέτη</strong> — Συντάσσουμε την τεχνική περιγραφή που περιλαμβάνει φωτογραφίες, αποτύπωμα αριθμού πλαισίου και όλα τα απαραίτητα έγγραφα.', en: '<strong>Full technical study</strong> — We prepare the technical description including photographs, chassis number imprint, and all required documents.' };
    T['ta.svc4']        = { el: '<strong>Υποβολή φακέλου</strong> — Ετοιμάζουμε και υποβάλλουμε τον πλήρη φάκελο στην αρμόδια υπηρεσία. Το μόνο που χρειάζεται να κάνετε είναι να μας <strong>τηλεφωνήσετε</strong>.', en: '<strong>File submission</strong> — We prepare and submit the complete file to the competent authority. All you need to do is <strong>call us</strong>.' };
    T['ta.cta.text']    = { el: 'Επικοινωνήστε μαζί μας για τη νομιμοποίηση του ρυμουλκούμενου ή της μπαγκαζιέρας σας.', en: 'Contact us about legalising your trailer or cargo box.' };
    T['ta.cta.btn']     = { el: 'Ζητήστε προσφορά', en: 'Request a quote' };

    // TYPE-APPROVAL SECTION (tap.*)
    T['tap.badge']       = { el: 'ΕΓΚΡΙΣΕΙΣ ΤΥΠΟΥ', en: 'TYPE APPROVALS' };
    T['tap.title']       = { el: 'Υπηρεσίες Έγκρισης Τύπου και Τεχνικής Υποστήριξης Οχημάτων', en: 'Vehicle Type Approval and Technical Support Services' };
    T['tap.kicker']      = { el: 'ΟΧΗΜΑΤΑ και ΡΥΜΟΥΛΚΟΥΜΕΝΑ', en: 'VEHICLES and TRAILERS' };
    T['tap.intro']       = { el: 'Πέρα από την <strong>έκδοση αδειών τρέιλερ</strong>, το γραφείο αναλαμβάνει το πλήρες φάσμα της <strong>έγκρισης τύπου</strong> και της τεχνικής υποστήριξης οχημάτων — από τη σύνταξη του φακέλου και τη μελέτη, έως την <strong>καταχώρηση στο ΤΑΟ</strong>, το <strong>Δελτίο Κοινοποίησης</strong> και την τελική ταξινόμηση.', en: 'Beyond <strong>trailer licensing</strong>, the office handles the full spectrum of <strong>type approval</strong> and vehicle technical support — from dossier preparation and technical study, through <strong>Technical Vehicle Archive (TAO) registration</strong> and the <strong>Notification Certificate</strong>, to final registration.' };
    T['tap.expand.hint'] = { el: 'ΔΕΣ ΟΛΕΣ ΤΙΣ ΥΠΗΡΕΣΙΕΣ ΕΓΚΡΙΣΕΩΝ ΤΥΠΟΥ ΑΝΑΛΥΤΙΚΑ', en: 'SEE ALL TYPE APPROVAL SERVICES IN DETAIL' };
    T['tap.graphic.tag'] = { el: 'ΦΑΚΕΛΟΣ ΕΓΚΡΙΣΗΣ ΤΥΠΟΥ', en: 'TYPE APPROVAL DOSSIER' };
    T['tap.graphic.alt'] = { el: 'Σκίτσο φακέλου έγκρισης τύπου οχήματος με σφραγίδα έγκρισης', en: 'Sketch of a vehicle type approval dossier with approval stamp' };
    T['tap.cta.text']    = { el: 'Έχετε όχημα, αμάξωμα ή ρυμουλκούμενο που χρειάζεται έγκριση; Επικοινωνήστε μαζί μας και θα σας πούμε πώς προχωράει.', en: 'Have a vehicle, body or trailer that needs approval? Contact us and we will tell you how it can proceed.' };
    T['tap.cta.btn']     = { el: 'Ζητήστε προσφορά', en: 'Request a quote' };
    // Text baked into the type-approval sketch animation (plain text, no entities)
    T['tap.doc.title']   = { el: 'ΕΓΚΡΙΣΗ ΤΥΠΟΥ', en: 'TYPE APPROVAL' };
    T['tap.doc.sub']     = { el: 'ΤΕΧΝΙΚΟΣ ΦΑΚΕΛΟΣ ΟΧΗΜΑΤΟΣ', en: 'VEHICLE TECHNICAL DOSSIER' };
    T['tap.doc.field']   = { el: 'ΑΡ. ΕΓΚΡΙΣΗΣ', en: 'APPROVAL No.' };
    T['tap.doc.chk1']    = { el: 'ΚΑΤΑΧΩΡΗΣΗ ΣΤΟ ΤΑΟ', en: 'TAO REGISTRATION' };
    T['tap.doc.chk2']    = { el: 'ΔΕΛΤΙΟ ΚΟΙΝΟΠΟΙΗΣΗΣ', en: 'NOTIFICATION CERTIFICATE' };
    T['tap.dim.label']   = { el: 'ΚΑΤΗΓΟΡΙΕΣ  M1 · N1 · N2 · O1 · O2', en: 'CATEGORIES  M1 · N1 · N2 · O1 · O2' };
    T['tap.stamp.main']  = { el: 'ΕΓΚΡΙΘΗΚΕ', en: 'APPROVED' };
    T['tap.stamp.sub']   = { el: 'ΕΓΚΡΙΣΗ ΤΥΠΟΥ', en: 'TYPE APPROVAL' };
    T['tap.stamp.top']   = { el: 'e13 · 2018/858', en: 'e13 · 2018/858' };
    T['tap.stamp.foot']  = { el: 'ΥΠ. ΥΠΟΔΟΜΩΝ · ΤΑΟ', en: 'MIN. OF INFRASTRUCTURE · TAO' };
    (C.services || []).forEach(function (s, i) {
        var n = i + 1;
        T['s' + n + '.title'] = { el: s.titleEl, en: s.titleEn };
        T['s' + n + '.text']  = { el: s.textEl,  en: s.textEn };
        if (s.moreEl) T['s' + n + '.more'] = { el: s.moreEl, en: s.moreEn || s.moreEl };
        /* Μία γραμμή κάτω από τον τίτλο της κάρτας: οι επιμέρους υπηρεσίες,
           ή η αρχή της περιγραφής (χωρίς HTML) όπου δεν υπάρχουν. */
        var plain = function (h) { return (h || '').replace(/<[^>]+>/g, ''); };
        T['s' + n + '.teaser'] = (s.items && s.items.length)
            ? { el: s.items.map(function (it) { return plain(it.titleEl); }).join(' · '),
                en: s.items.map(function (it) { return plain(it.titleEn); }).join(' · ') }
            : { el: plain(s.textEl), en: plain(s.textEn) };
        (s.items || []).forEach(function (it, j) {
            var k = j + 1;
            T['s' + n + '.i' + k + '.title'] = { el: it.titleEl, en: it.titleEn };
            T['s' + n + '.i' + k + '.text']  = { el: it.textEl,  en: it.textEn };
        });
    });

    // PROJECTS
    T['projects.eyebrow'] = { el: 'Το χαρτοφυλάκιό μας', en: 'Our Portfolio' };
    T['projects.heading'] = { el: 'Επιλεγμένα <em>Έργα</em>', en: 'Selected <em>Projects</em>' };
    (C.projects || []).forEach(function (p, i) {
        var n = i + 1;
        T['p' + n + '.cat']   = { el: p.catEl,   en: p.catEn };
        T['p' + n + '.title'] = { el: p.titleEl,  en: p.titleEn };
        T['p' + n + '.desc']  = { el: p.descEl,   en: p.descEn };
    });

    // CONTACT
    T['contact.eyebrow'] = { el: 'Επικοινωνία', en: 'Contact' };
    T['contact.heading'] = { el: 'Μιλήστε <em>μαζί μας</em>', en: 'Let\'s <em>talk</em>' };
    T['contact.lead']    = {
        el: 'Είμαστε εδώ για κάθε ερώτηση ή ανάγκη. Επικοινωνήστε μαζί μας και θα εξετάσουμε προσωπικά την περίπτωσή σας.',
        en: 'We\'re here for any question or need. Get in touch and we will look at your case personally.',
    };
    T['contact.role'] = { el: P.fullTitleEl, en: P.fullTitleEn };
    T['contact.area']    = { el: P.areaEl,               en: P.areaEn };
    T['contact.fax']     = { el: C.contact.fax || '',    en: C.contact.fax || '' };
    T['contact.address'] = { el: C.contact.address || '', en: C.contact.addressEn || '' };

    // FORM
    T['form.title']          = { el: 'Στείλτε μήνυμα',                      en: 'Send a Message' };
    T['form.label.name']     = { el: 'Ονοματεπώνυμο',                       en: 'Full Name' };
    T['form.ph.name']        = { el: '',                                    en: '' };
    T['form.label.phone']    = { el: 'Τηλέφωνο',                            en: 'Phone' };
    T['form.label.email']    = { el: 'Email',                                en: 'Email' };
    T['form.ph.email']       = { el: '',                                    en: '' };
    T['form.label.subject']  = { el: 'Αντικείμενο',                         en: 'Subject' };
    T['form.select.default'] = { el: 'Επιλέξτε υπηρεσία',                   en: 'Select a service' };
    T['form.label.message']  = { el: 'Μήνυμα',                              en: 'Message' };
    T['form.ph.message']     = { el: '',                                    en: '' };
    T['form.submit']         = { el: 'Αποστολή Μηνύματος',                  en: 'Send Message' };
    (C.formOptions || []).forEach(function (o, i) {
        T['form.opt.' + (i + 1)] = { el: o.el, en: o.en };
    });

    // TRUST
    var TR = C.trust || {};
    T['trust.eyebrow'] = { el: TR.eyebrowEl || '', en: TR.eyebrowEn || '' };
    T['trust.heading'] = { el: TR.headingEl || '', en: TR.headingEn || '' };
    (TR.stats || []).forEach(function (s, i) {
        var n = i + 1;
        T['trust.stat' + n + '.num']   = { el: injectYears(s.numEl),   en: injectYears(s.numEn) };
        T['trust.stat' + n + '.label'] = { el: s.labelEl, en: s.labelEn };
    });
    (TR.pillars || []).forEach(function (p, i) {
        var n = i + 1;
        T['trust.p' + n + '.title'] = { el: p.titleEl, en: p.titleEn };
        T['trust.p' + n + '.text']  = { el: p.textEl,  en: p.textEn };
    });

    // ARTICLES
    (C.articles || []).forEach(function (a, i) {
        var n = i + 1;
        T['art' + n + '.cat']   = { el: a.catEl,   en: a.catEn };
        T['art' + n + '.title'] = { el: a.titleEl, en: a.titleEn };
        T['art' + n + '.text']  = { el: a.textEl,  en: a.textEn };
    });

    // REVIEWS
    T['reviews.eyebrow'] = { el: 'Κριτικές Πελατών', en: 'Client Reviews' };
    T['reviews.heading'] = { el: 'Τι λένε <em>οι πελάτες</em> μας', en: 'What <em>our clients</em> say' };
    T['reviews.source']  = { el: 'Αξιολόγηση από Google', en: 'Review from Google' };
    T['reviews.more']    = { el: 'Περισσότερα', en: 'Read more' };
    T['reviews.less']    = { el: 'Λιγότερα', en: 'Show less' };
    (C.reviews || []).forEach(function (r, i) {
        var n = i + 1;
        T['review' + n + '.text'] = { el: r.textEl, en: r.textEn };
    });

    // FOOTER
    T['footer.title'] = { el: P.fullTitleEl.split(' | ').join('<br>'), en: P.fullTitleEn.split(' | ').join('<br>') };

    // ARIA LABELS
    T['aria.menu']      = { el: 'Μενού πλοήγησης',       en: 'Navigation menu' };
    T['aria.backToTop'] = { el: 'Επιστροφή στην κορυφή', en: 'Back to top' };

    // TRC WIDGET BADGE
    T['trc.badge'] = { el: 'Έλεγχος Κ.Ο.Κ.', en: 'Road Code Check' };

    // HERO BOTTOM CONTACT STRIP
    T['hbc.phone']        = { el: 'Σταθερό',      en: 'Landline' };
    T['hbc.service']      = { el: 'Εξυπηρέτηση', en: 'Service area' };
    T['contact.phone.val']  = { el: C.contact.phone,   en: C.contact.phoneEn  || C.contact.phone };
    T['contact.viber.val'] = { el: 'Στείλτε φωτογραφία', en: 'Send a photo' };

    // MEASURE LABELS
    T['services.meas'] = { el: 'ΥΠΗΡΕΣΙΕΣ', en: 'SERVICES' };
    T['projects.meas'] = { el: 'ΕΡΓΑ',       en: 'PROJECTS' };

    // SERVICE BADGE (featured card)
    T['service.badge.new'] = { el: 'ΝΕΑ', en: 'NEW' };
    T['services.meas.area'] = { el: 'Αθήνα — Θεσσαλονίκη', en: 'Athens — Thessaloniki' };

    // SERVICE INLINE EXPAND (cards 0 & 1)
    T['svc.expand.0.p1'] = {
        el: 'Κάθε τρέιλερ υποχρεούται από τον ΚΟΚ να διαθέτει <strong>άδεια κυκλοφορίας</strong> και πινακίδες. <strong>Ο1</strong>: έως 750 kg (μπαγκαζιέρα, σκάφη, camping, μοτοσυκλέτα) — <strong>Ο2</strong>: έως 3.500 kg (caravan, αυτοκινήτου, βαριά βιομηχανικά). Αναλαμβάνουμε πλήρως: <strong>έγκριση τύπου ρυμουλκούμενου</strong>, τεχνική μελέτη, υποβολή ΥΜΕΔ/ΚΤΕΟ, έκδοση άδειας.',
        en: 'Every trailer is required by Road Code to have a <strong>registration licence</strong> and plates. <strong>O1</strong>: up to 750 kg (cargo trailer, boats, camping, motorcycle) — <strong>O2</strong>: up to 3,500 kg (caravan, car, heavy industrial). We handle everything: <strong>trailer type approval</strong>, technical study, submission to YMED/KTEO, licence issuance.',
    };
    T['svc.expand.0.meta'] = {
        el: 'Αθήνα και Θεσσαλονίκη &nbsp;·&nbsp; ΑΠΘ, 3× MSc &nbsp;·&nbsp; Κατηγορίες Ο1 και Ο2',
        en: 'Athens and Thessaloniki &nbsp;·&nbsp; AUTH, 3× MSc &nbsp;·&nbsp; Categories O1 and O2',
    };
    T['svc.expand.1.p1'] = {
        el: 'Τα οχήματα ειδικής χρήσης — γερανοφόρα, πλατφόρμες, ψεκαστικά — χρειάζονται ειδική <strong>ταξινόμηση</strong> και <strong>έγκριση τύπου οχήματος</strong>. Αναλαμβάνουμε επίσης <strong>έγκριση τύπου ρυμουλκούμενου</strong> για τρέιλερ εκτός σειράς παραγωγής. Εκπονούμε τεχνικές μελέτες (στατική ανάλυση, CE, EN 1570) και αναλαμβάνουμε τη διαδικασία από την αρχή έως το τέλος.',
        en: 'Special use vehicles — crane trucks, platforms, sprayers — require special <strong>registration</strong> and <strong>vehicle type approval</strong>. We also handle <strong>trailer type approval</strong> for custom-built trailers. We prepare technical studies (static analysis, CE, EN 1570) and handle the entire process from start to finish.',
    };
    T['svc.expand.1.meta'] = {
        el: 'Γερανοφόρα &nbsp;·&nbsp; Πλατφόρμες &nbsp;·&nbsp; Ψεκαστικά &nbsp;·&nbsp; Αθήνα και Θεσσαλονίκη',
        en: 'Crane trucks &nbsp;·&nbsp; Platforms &nbsp;·&nbsp; Sprayers &nbsp;·&nbsp; Athens and Thessaloniki',
    };

    // NAV BRAND (for language switch)
    if (P.navBrandEl) {
        T['nav.brand'] = { el: P.navBrandEl, en: P.navBrandEn || P.navBrandEl };
    }

    // FOOTER BRAND (for language switch)
    T['footer.brand']   = { el: P.displayNameEl, en: P.displayNameEn || P.displayNameEl };
    T['contact.person'] = { el: P.displayNameEl, en: P.displayNameEn || P.displayNameEl };

    C.translations = T;


    // ── 2. CSS THEME VARIABLES ───────────────────────────────────────────────
    if (C.theme && C.theme.accent) {
        var themeStyle = document.createElement('style');
        themeStyle.textContent =
            ':root { --gold: ' + C.theme.accent + '; --gold2: ' + (C.theme.accentLight || C.theme.accent) + '; }';
        document.head.appendChild(themeStyle);
    }


    // ── 3. META TAGS ─────────────────────────────────────────────────────────
    var savedLang = C.meta.lang || 'el';
    var langKey   = savedLang === 'en' ? 'En' : 'El';

    document.title = C.meta['title' + langKey] || C.meta.titleEl || '';
    var descMeta = document.querySelector('meta[name="description"]');
    if (descMeta) descMeta.content = C.meta['description' + langKey] || C.meta.descriptionEl || '';

    document.documentElement.lang = savedLang;


    // ── 4. ASSETS ─────────────────────────────────────────────────────────────
    var accentColor = (C.theme && C.theme.accent) ? C.theme.accent : '#c99986';
    var fallbackInitials =
        '<div style="width:100%;height:100%;background:linear-gradient(135deg,#1a1410,#2d2010);' +
        'display:flex;align-items:center;justify-content:center;font-family:serif;' +
        'font-size:18px;font-weight:700;color:' + accentColor + '">' + P.initials + '</div>';

    /* istoselides v2.11 (ΜΗ-32): ΣΧΕΤΙΚΕΣ διαδρομές (ανοίγει και χωρίς διακομιστή) και ΤΟΠΙΚΗ
       εφεδρεία, μία φορά — πριν, το onerror φόρτωνε Unsplash/Flaticon και, αν αποτύγχανε κι αυτό,
       ξανάτρεχε σε βρόχο (229 αιτήματα σε 30″ με file://). */
    var _ROOT = /\/en\/(index\.html)?$/.test(location.pathname) ? '../' : '';
    function _rel(u) { return (u && u.charAt(0) === '/' && u.charAt(1) !== '/') ? _ROOT + u.slice(1) : u; }
    var _FALLBACK = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120"><rect width="120" height="120" fill="#0d1a2d"/>' +
        '<text x="60" y="72" text-anchor="middle" font-family="Georgia,serif" font-size="34" fill="#c99986">ΤΓΜ</text></svg>');
    function _fallbackOnce() { if (this.getAttribute('data-fallback')) return; this.setAttribute('data-fallback', '1'); this.src = _FALLBACK; }
    window.__imgFallbackOnce = _fallbackOnce;

    /* istoselides v2.12: alt στη γλώσσα της σελίδας (G2 — η αγγλική έπαιρνε το ελληνικό όνομα) */
    var _EN = !!(C.meta && C.meta.lang === 'en');
    var _NAME = _EN ? (P.displayNameEn || P.displayNameEl) : P.displayNameEl;
    document.querySelectorAll('.logo-img').forEach(function (img) {
        img.src = _rel(C.assets.logo);
        img.alt = _NAME + (_EN ? ' — logo' : ' — λογότυπο');
        img.onerror = function () { this.parentElement.innerHTML = fallbackInitials; };
    });

    var heroPhoto = document.getElementById('heroPhoto');
    if (heroPhoto) {
        heroPhoto.src = _rel(C.assets.photo);
        heroPhoto.alt = _NAME;
        heroPhoto.onerror = _fallbackOnce;
    }

    var slides = document.querySelectorAll('.hero-slide');
    (C.assets.heroSlides || []).forEach(function (src, i) {
        if (slides[i]) slides[i].style.backgroundImage = "url('" + _rel(src) + "')";
    });

    var personPhoto = document.getElementById('personPhoto');
    if (personPhoto) {
        personPhoto.src = _rel(C.assets.contactPhoto || C.assets.photo);
        personPhoto.alt = _NAME;
        personPhoto.onerror = _fallbackOnce;
    }


    // ── 4b. HERO BOTTOM CONTACT STRIP ────────────────────────────────────────
    var heroBottomContact = document.getElementById('heroBottomContact');
    if (heroBottomContact) {
        heroBottomContact.innerHTML =
            '<a href="' + C.contact.phoneTel + '" class="hbc-item">' +
                '<span class="hbc-icon"><i class="fa-solid fa-phone"></i></span>' +
                '<span class="hbc-text"><span class="hbc-label" data-i18n="hbc.phone">' + T['hbc.phone'].el + '</span><span class="hbc-val" data-i18n="contact.phone.val">' + C.contact.phone + '</span></span>' +
            '</a>' +
            '<span class="hbc-item hbc-address">' +
                '<span class="hbc-icon"><i class="fa-solid fa-location-dot"></i></span>' +
                '<span class="hbc-text"><span class="hbc-label" data-i18n="hbc.service">' + T['hbc.service'].el + '</span><span class="hbc-val" data-i18n="contact.address">' + (C.contact.address || '') + '</span></span>' +
            '</span>' +
            '<a href="mailto:' + C.contact.email + '" class="hbc-item">' +
                '<span class="hbc-icon"><i class="fa-solid fa-envelope"></i></span>' +
                '<span class="hbc-text"><span class="hbc-label">Email</span><span class="hbc-val">' + C.contact.email + '</span></span>' +
            '</a>';
    }

    // ── 5. NAMES ──────────────────────────────────────────────────────────────
    // navBrandName and footerBrandName are handled by data-i18n via applyLang

    // personName is handled by data-i18n="contact.person" via applyLang

    // footerBrandName is handled by data-i18n="footer.brand" via applyLang

    // Hero crosshair university label — hide if not set
    var chLabel = document.querySelector('.ch-label');
    if (chLabel) {
        chLabel.textContent = P.universityEl || '';
        if (!P.universityEl) chLabel.style.display = 'none';
    }


    // ── 6. CONTACT LINKS ──────────────────────────────────────────────────────
    document.querySelectorAll('.contact-phone').forEach(function (el) {
        el.href = C.contact.phoneTel;
        var val = el.querySelector('.cd-value') || el.querySelector('span');
        if (val) val.textContent = C.contact.phone;
    });


    document.querySelectorAll('.contact-email').forEach(function (el) {
        el.href = 'mailto:' + C.contact.email;
        var val = el.querySelector('.cd-value') || el.querySelector('span');
        if (val) val.textContent = C.contact.email;
    });

    var footerEmail = document.getElementById('footerEmail');
    if (footerEmail) footerEmail.href = 'mailto:' + C.contact.email;

    var mcbCall = document.getElementById('mcbCall');
    if (mcbCall && C.contact.phoneTel) mcbCall.href = C.contact.phoneTel;

    var footerPhone = document.getElementById('footerPhone');
    if (footerPhone) footerPhone.href = C.contact.phoneTel;

    var footerFacebook = document.getElementById('footerFacebook');
    if (footerFacebook && C.contact.facebook) footerFacebook.href = C.contact.facebook;

    var contactFacebook = document.getElementById('contactFacebook');
    if (contactFacebook && C.contact.facebook) contactFacebook.href = C.contact.facebook;


    // ── 7. MEASUREMENT LABELS (auto-generated from array lengths) ─────────────

    var servicesMeas = document.getElementById('servicesMeasLabel');
    if (servicesMeas) {
        var sCount = (C.services || []).filter(function (x) { return !x.desktopOnly; }).length;
        servicesMeas.innerHTML =
            sCount + ' <span data-i18n="services.meas">' + T['services.meas'].el + '</span>';
    }

    var projectsMeas = document.getElementById('projectsMeasLabel');
    if (projectsMeas) {
        var pCount = (C.projects || []).length;
        projectsMeas.innerHTML =
            pCount + ' <span data-i18n="projects.meas">' + T['projects.meas'].el + '</span>' +
            ' \u2014 ' + (pCount * 208).toFixed(2) + ' m\u00B2';
    }


    // ── 8. RENDER MARQUEE ─────────────────────────────────────────────────────
    var marqueeTrack = document.getElementById('marqueeTrack');
    if (marqueeTrack) {
        var mHtml = '';
        // Render twice for seamless CSS infinite loop
        [0, 1].forEach(function () {
            (C.marquee || []).forEach(function (m, i) {
                mHtml +=
                    '<div class="marquee-item">' +
                    '<span class="marquee-dot"></span>' +
                    '<span data-i18n="marquee.m' + (i + 1) + '">' + m.el + '</span>' +
                    '</div>';
            });
        });
        marqueeTrack.innerHTML = mHtml;
    }


    // ── 9. RENDER ABOUT FEATURES ──────────────────────────────────────────────
    var aboutFeatures = document.getElementById('aboutFeatures');
    if (aboutFeatures) {
        var fHtml = '';
        (A.features || []).forEach(function (f, i) {
            var n = i + 1;
            fHtml +=
                '<div class="feature-row" data-reveal>' +
                '<div class="feature-row-header">' +
                '<i class="fa-solid ' + f.icon + '"></i>' +
                '<strong data-i18n-html="feature.' + n + '.label">' + f.labelEl + '</strong>' +
                '</div>' +
                '<span data-i18n-html="feature.' + n + '.text">' + f.textEl + '</span>' +
                '</div>';
        });
        aboutFeatures.innerHTML = fHtml;
    }


    // ── 10. RENDER SERVICES GRID ──────────────────────────────────────────────
    var servicesGrid = document.getElementById('servicesGrid');
    if (servicesGrid) {
        var sHtml = '';
        (C.services || []).forEach(function (s, i) {
            var n   = i + 1;
            var pad = n < 10 ? '0' + n : '' + n;
            // Η κάρτα-στόχος (featured στο config) μπαίνει πρώτη και ξεχωρίζει·
            // το σήμα «ΝΕΑ» είναι ξεχωριστό (badge), ώστε να μένει στο τρέιλερ.
            var featuredClass = s.featured ? ' service-card--featured' : '';
            var featuredBadge = (s.badge === 'new') ?
                '<span class="service-badge" data-i18n="service.badge.new">' + T['service.badge.new'].el + '</span>' : '';
            // Odd-index (0,2,4,6) = left column, even-index (1,3,5,7) = right column
            var colClass = (i % 2 === 0) ? ' service-card--odd' : ' service-card--even';
            // Cards with a url become anchor elements
            var tag    = s.url ? 'a' : 'div';
            var urlAttr = s.url
                ? ' href="' + s.url + '" target="_blank" rel="noopener noreferrer"'
                : '';
            var kwMeta = s.seoKeywords
                ? '<meta itemprop="keywords" content="' + s.seoKeywords + '">'
                : '';
            // Extra expand content for cards 0 and 1 (goes inside their expand panel)
            var extraExpand = '';
            if (s.expand === '0') {
                extraExpand =
                    '<p data-i18n-html="svc.expand.0.p1">' + T['svc.expand.0.p1'].el + '</p>' +
                    '<p class="svc-inline-meta" data-i18n-html="svc.expand.0.meta">' + T['svc.expand.0.meta'].el + '</p>';
            } else if (s.expand === '1') {
                extraExpand =
                    '<p data-i18n-html="svc.expand.1.p1">' + T['svc.expand.1.p1'].el + '</p>' +
                    '<p class="svc-inline-meta" data-i18n-html="svc.expand.1.meta">' + T['svc.expand.1.meta'].el + '</p>';
            }
            // Optional sub-service list (e.g. type-approval breakdown)
            var itemsHtml = '';
            if (s.items && s.items.length) {
                itemsHtml += '<ul class="svc-inline-list">';
                s.items.forEach(function (it, j) {
                    var k = j + 1;
                    itemsHtml +=
                        '<li>' +
                        '<span class="svc-inline-list-t"' +
                        ' data-i18n-html="s' + n + '.i' + k + '.title">' + it.titleEl + '</span>' +
                        '<span class="svc-inline-list-d"' +
                        ' data-i18n-html="s' + n + '.i' + k + '.text">' + it.textEl + '</span>' +
                        '</li>';
                });
                itemsHtml += '</ul>';
            }
            // ── Κουμπιά προς τις αφιερωμένες σελίδες ──
            //    Το κείμενο του expand λέει τι κάνουμε· το κουμπί στέλνει τον
            //    επισκέπτη εκεί όπου τα λέμε αναλυτικά.
            var isEn    = (C.meta && C.meta.lang === 'en');
            var pageBtns = [];
            var svcPage  = isEn ? s.urlEn : s.urlEl;
            if (svcPage) {
                pageBtns.push({ href: svcPage, label: isEn ? 'Read the full page' : 'Δείτε τη σελίδα αναλυτικά' });
            }
            (s.items || []).forEach(function (it) {
                var u = isEn ? it.urlEn : it.urlEl;
                if (!u) return;
                for (var q = 0; q < pageBtns.length; q++) { if (pageBtns[q].href === u) return; }
                pageBtns.push({ href: u, label: isEn ? it.titleEn : it.titleEl });
            });
            // Σχετικές σελίδες χωρίς δική τους κάρτα (π.χ. κοτσαδόρος μέσα στην κάρτα του τρέιλερ):
            // κουμπί στην ίδια κάρτα, ώστε το πλέγμα να μένει συμμετρικό.
            (s.links || []).forEach(function (l) {
                var u = isEn ? l.urlEn : l.urlEl;
                if (u) pageBtns.push({ href: u, label: isEn ? l.labelEn : l.labelEl });
            });
            var pagesHtml = '';
            if (pageBtns.length) {
                pagesHtml = '<div class="svc-inline-cta">';
                pageBtns.forEach(function (pb) {
                    pagesHtml +=
                        '<a class="svc-inline-btn" href="' + pb.href + '">' +
                        '<span>' + pb.label + '</span>' +
                        '<i class="fa-solid fa-arrow-right" aria-hidden="true"></i></a>';
                });
                pagesHtml += '</div>';
            }

            // All cards are expandable; description moves into the expand panel
            var expandContent =
                '<div class="svc-inline-expand">' +
                '<div class="svc-inline-expand-inner">' +
                '<p itemprop="description" data-i18n-html="s' + n + '.text">' + s.textEl + '</p>' +
                itemsHtml +
                extraExpand +
                pagesHtml +
                '</div>' +
                '</div>';
            var pageAttr = svcPage ? ' data-page-el="' + (s.urlEl || svcPage) + '" data-page-en="' + (s.urlEn || svcPage) + '"' : '';
            sHtml +=
                '<' + tag + urlAttr + pageAttr + ' class="service-card' + featuredClass + colClass + ' service-card--expandable' + (svcPage ? ' service-card--page' : '') + (s.desktopOnly ? ' svc-desktop-only' : '') + '" data-reveal' +
                ' itemscope itemtype="https://schema.org/Service" itemprop="itemListElement">' +
                '<meta itemprop="position" content="' + n + '">' +
                kwMeta +
                '<div class="service-num" aria-hidden="true">' + pad + '</div>' +
                '<i class="fa-solid ' + s.icon + ' service-icon" aria-hidden="true"></i>' +
                '<div class="service-card-body">' +
                '<h3 itemprop="name" data-i18n-html="s' + n + '.title">' + s.titleEl + '</h3>' +
                '<p class="service-teaser" data-i18n-html="s' + n + '.teaser">' + T['s' + n + '.teaser'].el + '</p>' +
                featuredBadge +
                '</div>' +
                '<i class="fa-solid ' + (svcPage ? 'fa-arrow-right' : 'fa-chevron-down') + ' service-chev" aria-hidden="true"></i>' +
                expandContent +
                (svcPage ? (s.moreEl ? '<span class="svc-more" data-i18n="s' + n + '.more">' + s.moreEl + '</span>' : '<span class="svc-more" data-i18n="svc.more">' + T['svc.more'].el + '</span>') : '') +
                '</' + tag + '>';
        });
        servicesGrid.innerHTML = sHtml;

        // Wire expand panels — collapsed by default on all screen sizes
        servicesGrid.querySelectorAll('.service-card--expandable').forEach(function (card) {
            card.setAttribute('aria-expanded', 'false');
            if (card.getAttribute('data-page-el')) {
                card.setAttribute('role', 'link');
                card.setAttribute('tabindex', '0');
                card.removeAttribute('aria-expanded');
                card.addEventListener('keydown', function (e) {
                    if (e.key === 'Enter') card.click();
                });
            }
            card.addEventListener('click', function (e) {
                /* Κλικ σε κουμπί/σύνδεσμο: άφησέ το να πλοηγηθεί, μην κλείσεις την κάρτα */
                if (e.target.closest && e.target.closest('a.svc-inline-btn')) return;
                /* Κάρτα με δική της σελίδα: το κλικ ανοίγει τη σελίδα */
                var isEnNow = (document.documentElement.lang || '').indexOf('en') === 0;
                var pg = card.getAttribute(isEnNow ? 'data-page-en' : 'data-page-el');
                if (pg) { window.location.href = pg; return; }
                var panel = card.querySelector('.svc-inline-expand');
                if (!panel) return;
                var open = panel.classList.toggle('is-open');
                card.setAttribute('aria-expanded', String(open));
            });
        });

        // Start featured-card animation when it scrolls into view
        var fc = servicesGrid.querySelector('.service-card--featured');
        if (fc) {
            var fcObs = new IntersectionObserver(function(entries) {
                entries.forEach(function(entry) {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('is-visible');
                        fcObs.unobserve(entry.target);
                    }
                });
            }, { threshold: 0 });
            fcObs.observe(fc);
        }
    }


    // ── 10b. RENDER TYPE-APPROVAL SECTION GRID ────────────────────────────────
    /* Built from the same C.services entries that carry an items[] array, so the
       section and the service cards can never drift apart, in either language. */
    var tapGrid = document.getElementById('tapGrid');
    if (tapGrid) {
        var tHtml = '';
        (C.services || []).forEach(function (s, i) {
            if (!s.items || !s.items.length) return;
            var n = i + 1;
            tHtml +=
                '<div class="tap-col" data-reveal>' +
                '<div class="tap-col-head">' +
                '<i class="fa-solid ' + s.icon + ' tap-col-icon" aria-hidden="true"></i>' +
                '<h3 class="tap-col-title" data-i18n-html="s' + n + '.title">' + s.titleEl + '</h3>' +
                '</div>' +
                '<ul class="tap-list">';
            s.items.forEach(function (it, j) {
                var k = j + 1;
                tHtml +=
                    '<li class="tap-item">' +
                    '<span class="tap-item-num" aria-hidden="true">' +
                    (k < 10 ? '0' + k : '' + k) + '</span>' +
                    (function () {
                        var href = (C.meta && C.meta.lang === 'en') ? it.urlEn : it.urlEl;
                        var body =
                            '<span class="tap-item-t" data-i18n-html="s' + n + '.i' + k + '.title">' +
                            it.titleEl + '</span>' +
                            '<span class="tap-item-d" data-i18n-html="s' + n + '.i' + k + '.text">' +
                            it.textEl + '</span>';
                        return href
                            ? '<a class="tap-item-body tap-item-link" href="' + href + '">' + body + '</a>'
                            : '<span class="tap-item-body">' + body + '</span>';
                    })() +
                    '</li>';
            });
            tHtml += '</ul></div>';
        });
        tapGrid.innerHTML = tHtml;
    }

    // Wire the type-approval section collapse toggle
    var tapToggle = document.getElementById('tapToggle');
    var tapCollapse = document.getElementById('tapCollapse');
    if (tapToggle && tapCollapse) {
        tapToggle.addEventListener('click', function () {
            var open = tapCollapse.classList.toggle('is-open');
            tapToggle.setAttribute('aria-expanded', String(open));
        });
    }


    // ── 11. RENDER PROJECTS GRID ──────────────────────────────────────────────
    var projectsGrid = document.getElementById('projectsGrid');
    if (projectsGrid) {
        var pHtml = '';
        (C.projects || []).forEach(function (p, i) {
            var n = i + 1;
            pHtml +=
                '<div class="project-card" data-reveal>' +
                '<img src="' + p.image + '" alt="" ' +
                'onerror="window.__imgFallbackOnce && window.__imgFallbackOnce.call(this)">' +
                '<div class="project-card-overlay"></div>' +
                '<div class="project-card-info">' +
                '<div class="project-cat" data-i18n="p' + n + '.cat">'  + p.catEl   + '</div>' +
                '<h3 data-i18n="p' + n + '.title">'                     + p.titleEl + '</h3>' +
                '<p data-i18n="p' + n + '.desc">'                       + p.descEl  + '</p>' +
                '</div>' +
                '</div>';
        });
        projectsGrid.innerHTML = pHtml;
    }


    // ── 12. RENDER TRUST STATS ────────────────────────────────────────────────
    var trustStats = document.getElementById('trustStats');
    if (trustStats && TR.stats) {
        var tsHtml = '';
        (TR.stats || []).forEach(function (s, i) {
            var n = i + 1;
            tsHtml +=
                '<div class="trust-stat" data-reveal itemscope itemtype="https://schema.org/QuantitativeValue">' +
                '<span class="trust-stat-num" data-i18n="trust.stat' + n + '.num" itemprop="value">' + s.numEl + '</span>' +
                '<span class="trust-stat-label" data-i18n="trust.stat' + n + '.label" itemprop="unitText">' + s.labelEl + '</span>' +
                '</div>';
        });
        trustStats.innerHTML = tsHtml;
    }

    // ── 13. RENDER TRUST PILLARS ──────────────────────────────────────────────
    var trustPillars = document.getElementById('trustPillars');
    if (trustPillars && TR.pillars) {
        var tpHtml = '';
        (TR.pillars || []).forEach(function (p, i) {
            var n = i + 1;
            tpHtml +=
                '<div class="trust-pillar" data-reveal itemscope itemtype="https://schema.org/Thing">' +
                '<div class="trust-pillar-icon" aria-hidden="true"><i class="fa-solid ' + p.icon + '"></i></div>' +
                '<h3 itemprop="name" data-i18n-html="trust.p' + n + '.title">' + p.titleEl + '</h3>' +
                '<p itemprop="description" data-i18n-html="trust.p' + n + '.text">'   + p.textEl  + '</p>' +
                '</div>';
        });
        trustPillars.innerHTML = tpHtml;
    }

    // ── 14. RENDER ARTICLES TICKER ────────────────────────────────────────────
    var articlesTrack = document.getElementById('articlesTrack');
    if (articlesTrack && C.articles) {
        var aHtml = '';
        // Render twice for seamless infinite loop
        [0, 1].forEach(function () {
            (C.articles || []).forEach(function (a, i) {
                var n = i + 1;
                aHtml +=
                    '<a class="article-card" href="' + (a.url || '#') + '" target="_blank" rel="noopener noreferrer"' +
                    ' onclick="window.ccEvent&&ccEvent(\'article_click\',{article_title:\'' + a.titleEn.replace(/'/g, '') + '\',article_category:\'' + a.catEn.replace(/'/g, '') + '\'})"' +
                    '<span class="article-cat" data-i18n="art' + n + '.cat">' + a.catEl + '</span>' +
                    '<h4 data-i18n-html="art' + n + '.title">' + a.titleEl + '</h4>' +
                    '<p data-i18n-html="art' + n + '.text">'   + a.textEl  + '</p>' +
                    '</a>';
            });
        });
        articlesTrack.innerHTML = aHtml;
    }

    // ── 14b. RENDER GOOGLE REVIEWS CAROUSEL ──────────────────────────────────
    var reviewsTrack = document.getElementById('reviewsTrack');
    if (reviewsTrack && C.reviews) {
        var starsHtml = '<span class="review-stars" aria-hidden="true">' +
            '<i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>' +
            '<i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i>' +
            '<i class="fa-solid fa-star"></i></span>';
        var googleIconHtml =
            '<svg class="review-google-icon" viewBox="0 0 48 48" width="18" height="18" aria-hidden="true">' +
            '<path fill="#4285F4" d="M45.12 24.5c0-1.56-.14-3.06-.4-4.5H24v8.51h11.84c-.51 2.75-2.06 5.08-4.39 6.64v5.52h7.11c4.16-3.83 6.56-9.47 6.56-16.17z"/>' +
            '<path fill="#34A853" d="M24 46c5.94 0 10.92-1.97 14.56-5.33l-7.11-5.52c-1.97 1.32-4.49 2.1-7.45 2.1-5.73 0-10.58-3.87-12.31-9.07H4.34v5.7C7.96 41.07 15.4 46 24 46z"/>' +
            '<path fill="#FBBC05" d="M11.69 28.18C11.25 26.86 11 25.45 11 24s.25-2.86.69-4.18v-5.7H4.34C2.85 17.09 2 20.45 2 24s.85 6.91 2.34 9.88l7.35-5.7z"/>' +
            '<path fill="#EA4335" d="M24 10.75c3.23 0 6.13 1.11 8.41 3.29l6.31-6.31C34.91 4.18 29.93 2 24 2 15.4 2 7.96 6.93 4.34 14.12l7.35 5.7c1.73-5.2 6.58-9.07 12.31-9.07z"/>' +
            '</svg>';
        var rHtml = '';
        // Render twice for seamless infinite loop
        [0, 1].forEach(function () {
            (C.reviews || []).forEach(function (r, i) {
                var n = i + 1;
                var initial = (r.name || '?').trim().charAt(0).toUpperCase();
                rHtml +=
                    '<div class="review-card">' +
                    '<div class="review-head">' +
                    '<div class="review-avatar" aria-hidden="true">' + initial + '</div>' +
                    '<div class="review-head-text">' +
                    /* ελληνικό όνομα σε αγγλική σελίδα: lang="el" (G1) */
                    '<h3' + (/[\u0370-\u03FF\u1F00-\u1FFF]/.test(r.name) ? ' lang="el"' : '') + '>' + r.name + '</h3>' +
                    '<span class="review-source" data-i18n="reviews.source"></span>' +
                    '</div>' +
                    googleIconHtml +
                    '</div>' +
                    starsHtml +
                    '<p data-i18n="review' + n + '.text">' + r.textEl + '</p>' +
                    '<button type="button" class="review-more" aria-expanded="false">' +
                    '<span class="rm-more" data-i18n="reviews.more">Περισσότερα</span>' +
                    '<span class="rm-less" data-i18n="reviews.less">Λιγότερα</span>' +
                    '<i class="fa-solid fa-chevron-down" aria-hidden="true"></i></button>' +
                    '</div>';
            });
        });
        reviewsTrack.innerHTML = rHtml;

        /* Σταθερό ύψος κάρτας (ως 1/3 της οθόνης). Το κουμπί «Περισσότερα»
           εμφανίζεται μόνο όταν το κείμενο δεν χωρά· ξαναμετράμε σε αλλαγή
           μεγέθους και σε αλλαγή γλώσσας (αλλάζει το κείμενο). */
        var measureReviews = function () {
            reviewsTrack.querySelectorAll('.review-card').forEach(function (card) {
                if (card.classList.contains('is-expanded')) return;
                var p = card.querySelector('p');
                card.classList.toggle('has-more', p.scrollHeight > p.clientHeight + 2);
            });
        };
        var rvTimer;
        var remeasure = function () { clearTimeout(rvTimer); rvTimer = setTimeout(measureReviews, 120); };
        window.addEventListener('resize', remeasure);
        window.addEventListener('load', remeasure);
        if ('MutationObserver' in window) {
            new MutationObserver(remeasure).observe(reviewsTrack, { subtree: true, characterData: true, childList: true });
        }
        if (document.fonts && document.fonts.ready) document.fonts.ready.then(remeasure);
        remeasure();

        reviewsTrack.addEventListener('click', function (e) {
            var btn = e.target.closest && e.target.closest('.review-more');
            if (!btn) return;
            var card = btn.closest('.review-card');
            var open = !card.classList.contains('is-expanded');
            card.classList.toggle('is-expanded', open);
            btn.setAttribute('aria-expanded', String(open));
        });
    }

    // ── 15. RENDER FORM DROPDOWN ──────────────────────────────────────────────
    var serviceSelect = document.getElementById('serviceSelect');
    if (serviceSelect) {
        var optHtml = '<option value="" disabled selected data-i18n="form.select.default">Επιλέξτε υπηρεσία</option>';
        (C.formOptions || []).forEach(function (o, i) {
            optHtml += '<option value="' + (i + 1) + '" data-i18n="form.opt.' + (i + 1) + '">' + o.el + '</option>';
        });
        serviceSelect.innerHTML = optHtml;
    }

    // ── ADD phone placeholder translation ─────────────────────────────────────
    T['form.ph.phone'] = { el: '', en: '' };

    // No re-apply needed: i18n.js runs after this script and sees the fully-rendered DOM.

})();
