/**
 * i18n.js — Greek / English translation toggle
 * ════════════════════════════════════════════════════════════════════════════
 * Modular & reusable. Drop into any page that uses data-i18n attributes.
 * Translations come from window.SITE_CONFIG.translations (built by site-init.js).
 *
 * Attributes recognised:
 *   data-i18n="key"             → replaces element.textContent
 *   data-i18n-html="key"        → replaces element.innerHTML
 *   data-i18n-placeholder="key" → replaces element.placeholder
 *
 * Public API:
 *   window.I18n.setLang('el' | 'en')
 *   window.I18n.getLang()
 *   window.setLang(lang)          ← shorthand for onclick="setLang('el')"
 * ════════════════════════════════════════════════════════════════════════════
 */

(function () {
    'use strict';

    /* ─── TRANSLATIONS ────────────────────────────────────────────────────
     * Built by site-init.js from window.SITE_CONFIG and attached to
     * window.SITE_CONFIG.translations before this script runs.           */
    var t = (window.SITE_CONFIG && window.SITE_CONFIG.translations) || {};

    /* ─── STATE ──────────────────────────────────────────────────────────── */
    var currentLang = (window.SITE_CONFIG && window.SITE_CONFIG.meta && window.SITE_CONFIG.meta.lang) ||
                      'el';

    /* ─── APPLY TRANSLATIONS ─────────────────────────────────────────────── */
    function applyLang(lang) {
        currentLang = lang;
        /* Σε ιδιωτική περιήγηση (π.χ. παλιό Safari) το localStorage πετά σφάλμα
           και θα σταματούσε όλη τη μετάφραση — γι' αυτό σε try/catch. */
        try { localStorage.setItem('lang', lang); } catch (e) { /* ιδιωτική περιήγηση: συνεχίζουμε χωρίς αποθήκευση */ }

        /* text content */
        document.querySelectorAll('[data-i18n]').forEach(function (el) {
            var key = el.getAttribute('data-i18n');
            if (t[key] && t[key][lang] !== undefined) {
                el.textContent = t[key][lang];
            }
        });

        /* innerHTML (for keys with embedded HTML tags) */
        document.querySelectorAll('[data-i18n-html]').forEach(function (el) {
            var key = el.getAttribute('data-i18n-html');
            if (t[key] && t[key][lang] !== undefined) {
                el.innerHTML = t[key][lang];
            }
        });

        /* placeholder attribute */
        document.querySelectorAll('[data-i18n-placeholder]').forEach(function (el) {
            var key = el.getAttribute('data-i18n-placeholder');
            if (t[key] && t[key][lang] !== undefined) {
                el.placeholder = t[key][lang];
            }
        });

        /* aria-label attribute */
        document.querySelectorAll('[data-i18n-aria-label]').forEach(function (el) {
            var key = el.getAttribute('data-i18n-aria-label');
            if (t[key] && t[key][lang] !== undefined) {
                el.setAttribute('aria-label', t[key][lang]);
            }
        });

        /* href — links to per-language subpages (e.g. /en/foo/ vs /foo/) */
        document.querySelectorAll('[data-href-el]').forEach(function (el) {
            var url = el.getAttribute(lang === 'en' ? 'data-href-en' : 'data-href-el');
            if (url) el.setAttribute('href', url);
        });

        /* update <html lang> attribute */
        document.documentElement.lang = lang;

        /* update toggle button states */
        document.querySelectorAll('.lang-btn').forEach(function (btn) {
            btn.classList.toggle('active', btn.getAttribute('data-lang') === lang);
        });

        /* update page title and meta description */
        if (window.SITE_CONFIG && window.SITE_CONFIG.meta) {
            var M   = window.SITE_CONFIG.meta;
            var key = lang === 'en' ? 'En' : 'El';
            if (M['title' + key])       document.title = M['title' + key];
            var descEl = document.querySelector('meta[name="description"]');
            if (descEl && M['description' + key]) descEl.content = M['description' + key];
        }
    }

    /* ─── PUBLIC API ─────────────────────────────────────────────────────── */
    window.I18n = {
        setLang:      applyLang,
        getLang:      function () { return currentLang; },
        translations: t,
    };

    /* Αρχική: η αλλαγή γλώσσας πηγαίνει στην αντίστοιχη σελίδα (/ ↔ /en/), ώστε
       όλα τα κινούμενα σχέδια και οι υπολογιστές να φορτώσουν στη σωστή γλώσσα. */
    function switchLang(lang) {
        var native = (window.SITE_CONFIG && window.SITE_CONFIG.meta && window.SITE_CONFIG.meta.lang) || 'el';
        var p = location.pathname;
        var isHome = /^\/(index\.html)?$/.test(p) || /^\/en\/(index\.html)?$/.test(p);
        if (isHome && lang !== native) {
            try { localStorage.setItem('lang', lang); } catch (e) { /* ιδιωτική περιήγηση */ }
            location.href = (lang === 'en' ? '/en/' : '/') + location.hash;
            return;
        }
        applyLang(lang);
    }
    window.I18n.setLang = switchLang;

    /* Global shorthand for onclick="setLang('en')" buttons */
    window.setLang = switchLang;

    /* ─── INIT ───────────────────────────────────────────────────────────── */
    /* Apply on DOM ready — handles page reload with saved language preference */
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () { applyLang(currentLang); });
    } else {
        applyLang(currentLang);
    }

})();
